var searchData=
[
  ['api_0',['Introduction to the API',['../intro_guide.html',1,'']]],
  ['applications_1',['Building applications',['../build_guide.html',1,'']]]
];
